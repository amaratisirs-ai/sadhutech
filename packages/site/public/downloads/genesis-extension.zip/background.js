"use strict";
(() => {
  // src/background.ts
  var GATE_URL = "https://genesis-gate.onrender.com";
  var PRO_AUTH_TTL_MS = 23 * 60 * 60 * 1e3;
  function parseChainId(hex) {
    if (typeof hex !== "string") return 1;
    const n = Number.parseInt(hex, 16);
    return Number.isFinite(n) && n > 0 ? n : 1;
  }
  var GATE_TIMEOUT_MS = 5e3;
  function fetchWithTimeout(url, init) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), GATE_TIMEOUT_MS);
    return fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timer));
  }
  async function getActiveProAuth() {
    const stored = await chrome.storage.local.get(["deepCheckEnabled", "genesisProAuth"]);
    if (!stored.deepCheckEnabled) return null;
    const auth = stored.genesisProAuth;
    if (!auth || Date.now() - auth.ts >= PRO_AUTH_TTL_MS) return null;
    return auth;
  }
  async function analyze(request) {
    try {
      if (request.method === "eth_sendTransaction") {
        const tx = request.params[0];
        if (!tx?.to || !tx?.from) throw new Error("Malformed transaction request");
        const proAuth = await getActiveProAuth();
        const res2 = await fetchWithTimeout(`${GATE_URL}/v1/analyze`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            tx: {
              chainId: parseChainId(tx.chainId),
              from: tx.from,
              to: tx.to,
              value: typeof tx.value === "string" ? tx.value : "0",
              data: tx.data ?? "0x"
            },
            ...proAuth && {
              pro: { wallet: proAuth.address, message: proAuth.message, signature: proAuth.signature, source: "extension" }
            }
          })
        });
        if (!res2.ok) throw new Error(`Gate returned ${res2.status}`);
        const data2 = await res2.json();
        return {
          verdict: data2.verdict,
          plainEnglish: data2.plainEnglish ?? data2.summary ?? "",
          creditsLeft: typeof data2.creditsLeft === "number" ? data2.creditsLeft : void 0
        };
      }
      const isTyped = request.method === "eth_signTypedData_v4";
      const from = isTyped ? request.params[0] : request.params[1];
      const data = isTyped ? request.params[1] : request.params[0];
      if (!from || !data) throw new Error("Malformed signature request");
      const res = await fetchWithTimeout(`${GATE_URL}/v1/analyze-signature`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          sig: { chainId: 1, from, method: request.method, data, origin: request.origin }
        })
      });
      if (!res.ok) throw new Error(`Gate returned ${res.status}`);
      const result = await res.json();
      return { verdict: result.verdict, plainEnglish: result.plainEnglish ?? result.summary ?? "" };
    } catch (err) {
      return { verdict: "allow", plainEnglish: "", error: err instanceof Error ? err.message : String(err) };
    }
  }
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    analyze(request).then(sendResponse);
    return true;
  });
  var ALLOWED_CONNECT_ORIGINS = ["https://sadhutech.com", "https://sadhutech-site.vercel.app", "http://localhost:3000"];
  chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    if (message?.type !== "genesis-connect-result" || !ALLOWED_CONNECT_ORIGINS.includes(sender.origin ?? "")) return;
    const { address, authMessage, signature } = message;
    if (!address || !authMessage || !signature) {
      sendResponse({ ok: false, error: "Missing address, message, or signature." });
      return;
    }
    chrome.storage.local.set({ deepCheckEnabled: true, genesisProAuth: { address, message: authMessage, signature, ts: Date.now() } }).then(() => sendResponse({ ok: true }));
    return true;
  });
})();
//# sourceMappingURL=background.js.map
