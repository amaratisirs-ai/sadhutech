"use strict";
(() => {
  // src/messages.ts
  var GENESIS_REQUEST_EVENT = "genesis:analyze-request";
  var GENESIS_RESPONSE_EVENT = "genesis:analyze-response";

  // src/overlay.ts
  var THEME = {
    warn: { bg: "#451a03", border: "#f59e0b", label: "WARNING" },
    block: { bg: "#450a0a", border: "#ef4444", label: "BLOCKED BY GENESIS" }
  };
  function showChecking() {
    const pill = document.createElement("div");
    pill.style.cssText = `
    position: fixed; top: 16px; right: 16px; z-index: 2147483647; display: flex; align-items: center;
    gap: 8px; padding: 10px 14px; border-radius: 999px; background: #0f172a; border: 1px solid #334155;
    color: #cbd5e1; font: 600 12px system-ui, sans-serif; box-shadow: 0 8px 24px rgba(0,0,0,0.35);
  `;
    pill.innerHTML = `
    <span style="width: 12px; height: 12px; border: 2px solid #475569; border-top-color: #2dd4bf;
                 border-radius: 50%; display: inline-block; animation: genesis-spin 0.7s linear infinite;"></span>
    GENESIS checking...
    <style>@keyframes genesis-spin { to { transform: rotate(360deg); } }</style>
  `;
    document.documentElement.appendChild(pill);
    return () => pill.remove();
  }
  function showCreditNotice(creditsLeft) {
    const pill = document.createElement("div");
    pill.style.cssText = `
    position: fixed; top: 16px; right: 16px; z-index: 2147483647; padding: 10px 14px;
    border-radius: 999px; background: #0f172a; border: 1px solid #2dd4bf; color: #5eead4;
    font: 600 12px system-ui, sans-serif; box-shadow: 0 8px 24px rgba(0,0,0,0.35);
  `;
    pill.textContent = `\u{1F6E1} Deep Check used \u2014 ${creditsLeft} credit${creditsLeft === 1 ? "" : "s"} left`;
    document.documentElement.appendChild(pill);
    setTimeout(() => pill.remove(), 3e3);
  }
  function showOverlay(verdict, plainEnglish) {
    return new Promise((resolve) => {
      const theme = THEME[verdict];
      const root = document.createElement("div");
      root.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center;
      justify-content: center; background: rgba(0,0,0,0.75); font-family: system-ui, sans-serif;
    `;
      root.innerHTML = `
      <div style="max-width: 420px; width: 90%; background: ${theme.bg}; border: 2px solid ${theme.border};
                  border-radius: 16px; padding: 24px; color: #f1f5f9; box-shadow: 0 20px 60px rgba(0,0,0,0.5);">
        <div style="font-size: 12px; font-weight: 700; letter-spacing: 0.05em; color: ${theme.border}; margin-bottom: 8px;">
          \u{1F6E1} GENESIS &middot; ${theme.label}
        </div>
        <p style="font-size: 14px; line-height: 1.5; margin: 0 0 20px;">${plainEnglish}</p>
        <div style="display: flex; gap: 10px;">
          <button id="genesis-cancel" style="flex: 1; padding: 10px; border-radius: 8px; border: none;
                  background: #1e293b; color: #f1f5f9; font-weight: 600; cursor: pointer;">Cancel</button>
          <button id="genesis-proceed" style="flex: 1; padding: 10px; border-radius: 8px; border: none;
                  background: ${theme.border}; color: #0f172a; font-weight: 700; cursor: pointer;">Proceed anyway</button>
        </div>
      </div>
    `;
      document.documentElement.appendChild(root);
      const cleanup = (proceed) => {
        root.remove();
        resolve(proceed);
      };
      root.querySelector("#genesis-cancel")?.addEventListener("click", () => cleanup(false));
      root.querySelector("#genesis-proceed")?.addEventListener("click", () => cleanup(true));
    });
  }

  // src/content-script.ts
  window.addEventListener(GENESIS_REQUEST_EVENT, async (event) => {
    const request = event.detail;
    if (!request) return;
    const settings = await chrome.storage.local.get("genesisEnabled");
    if (settings.genesisEnabled === false) {
      respond({ type: GENESIS_RESPONSE_EVENT, id: request.id, verdict: "allow", plainEnglish: "", proceed: true });
      return;
    }
    const dismissChecking = showChecking();
    let analysis;
    try {
      analysis = await chrome.runtime.sendMessage(request);
    } catch (err) {
      dismissChecking();
      respond({ type: GENESIS_RESPONSE_EVENT, id: request.id, verdict: "allow", plainEnglish: "", proceed: true });
      return;
    }
    if (analysis.verdict === "allow") {
      dismissChecking();
      if (typeof analysis.creditsLeft === "number") showCreditNotice(analysis.creditsLeft);
      respond({
        type: GENESIS_RESPONSE_EVENT,
        id: request.id,
        verdict: "allow",
        plainEnglish: analysis.plainEnglish,
        proceed: true,
        creditsLeft: analysis.creditsLeft
      });
      return;
    }
    dismissChecking();
    const plainEnglish = typeof analysis.creditsLeft === "number" ? `${analysis.plainEnglish}

(1 Deep Check credit used, ${analysis.creditsLeft} remaining.)` : analysis.plainEnglish;
    const proceed = await showOverlay(analysis.verdict, plainEnglish);
    respond({ type: GENESIS_RESPONSE_EVENT, id: request.id, verdict: analysis.verdict, plainEnglish, proceed, creditsLeft: analysis.creditsLeft });
  });
  function respond(message) {
    window.dispatchEvent(new CustomEvent(GENESIS_RESPONSE_EVENT, { detail: message }));
  }
})();
//# sourceMappingURL=content-script.js.map
