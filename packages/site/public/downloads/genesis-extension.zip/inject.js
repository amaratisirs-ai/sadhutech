"use strict";
(() => {
  // src/messages.ts
  var GENESIS_REQUEST_EVENT = "genesis:analyze-request";
  var GENESIS_RESPONSE_EVENT = "genesis:analyze-response";

  // src/inject.ts
  var INTERCEPTED = /* @__PURE__ */ new Set([
    "eth_sendTransaction",
    "personal_sign",
    "eth_signTypedData_v4"
  ]);
  var nextId = 0;
  function askGenesis(method, params) {
    const id = `genesis-${Date.now()}-${nextId++}`;
    return new Promise((resolve) => {
      const onResponse = (event) => {
        const detail = event.detail;
        if (detail?.id !== id) return;
        window.removeEventListener(GENESIS_RESPONSE_EVENT, onResponse);
        resolve(detail);
      };
      window.addEventListener(GENESIS_RESPONSE_EVENT, onResponse);
      const message = {
        type: GENESIS_REQUEST_EVENT,
        id,
        method,
        params,
        origin: window.location.origin
      };
      window.dispatchEvent(new CustomEvent(GENESIS_REQUEST_EVENT, { detail: message }));
    });
  }
  function wrapProvider(provider) {
    if (!provider || provider.__genesisWrapped) return;
    const originalRequest = provider.request?.bind(provider);
    if (typeof originalRequest !== "function") return;
    provider.request = async (args) => {
      if (!INTERCEPTED.has(args.method)) {
        return originalRequest(args);
      }
      const result = await askGenesis(args.method, args.params ?? []);
      if (!result.proceed) {
        throw new Error(result.error || `GENESIS blocked this request: ${result.plainEnglish}`);
      }
      return originalRequest(args);
    };
    provider.__genesisWrapped = true;
  }
  function watchForProvider() {
    const w = window;
    if (w.ethereum) {
      wrapProvider(w.ethereum);
      return;
    }
    let attempts = 0;
    const timer = setInterval(() => {
      attempts += 1;
      if (w.ethereum) {
        wrapProvider(w.ethereum);
        clearInterval(timer);
      } else if (attempts > 40) {
        clearInterval(timer);
      }
    }, 250);
  }
  watchForProvider();
  window.addEventListener("eip6963:announceProvider", (event) => {
    const provider = event.detail?.provider;
    if (provider) wrapProvider(provider);
  });
  window.dispatchEvent(new Event("eip6963:requestProvider"));
})();
//# sourceMappingURL=inject.js.map
